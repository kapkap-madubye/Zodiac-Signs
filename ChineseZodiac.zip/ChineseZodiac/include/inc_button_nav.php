<a href = "index.php?page=home_page">
<img class="btn" src="images/homepage.png" alt="[Home Page]" title="Home Page"style = "border:0" /></a><br />

<a href = "index.php?page=site_layout">
<img class="btn" src="images/sitelayout.png" alt="[Site Layout]" title="Site Layout"style = "border:0" /></a><br />

<a href = "index.php?page=control_structures">
<img class="btn" src="images/controlstructures.png" alt="[Control Structures]" title="Control Structures"style = "border:0" /></a><br />

<a href = "index.php?page=string_functions">
<img class="btn" src="images/stringfunctions.png" alt="[String Functions]" title="Control Functions"style = "border:0" /></a><br />

<a href = "index.php?page=web_forms">
<img class="btn" src="images/webforms.png" alt="[Web Forms]" title="Web Forms"style = "border:0" /></a><br />

<a href = "index.php?page=midterm_assignment">
<img class="btn" src="images/midtermassignment.png" alt="[Midterm Assignment]" title="Midterm Assignment"style = "border:0" /></a><br />

<a href = "index.php?page=state_information">
<img class="btn" src="images/stateinformation.png" alt="[State Information]" title="State Information"style = "border:0" /></a><br />

<a href = "index.php?page=final_project">
<img class="btn" src="images/finalproject.png" alt="[Final Project]" title="Final Project"style = "border:0" /></a><br />
