<h3>[ Midterm assignment placeholder ]</h3>
